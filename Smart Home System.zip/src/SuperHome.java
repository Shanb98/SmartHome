public interface SuperHome {
    public void operate(String status);
    public String getName();
}
